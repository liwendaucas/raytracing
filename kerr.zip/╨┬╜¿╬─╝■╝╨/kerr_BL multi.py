# 论文版本
import sys
import time
import ctypes
import datetime
import numpy as np
import matplotlib.pyplot as plt
import multiprocessing as multi
from numpy import sin, cos, sqrt, zeros, pi

# global constant
a = 0.99999
rin = 2
rout = 4
R0 = 20
pitch = 15
THETA0 = (90-pitch)*pi/180
PHI0 = 0
RESOLUTION = [30, 30]
rotate = np.array([-pitch, 0, 0])*pi/180

steps = 100000
pixelindices = np.arange(0, RESOLUTION[0]*RESOLUTION[1], 1)
numPixels = pixelindices.shape[0]
NTHREADS = 10
CHUNKSIZE = int(numPixels/NTHREADS)+1
itcounters = [0 for i in range(NTHREADS)]
announce = 500

# region initialize
hori = 1 + sqrt(1-a**2) + 0.01 if abs(a) <= 1 else 0.01


class Outputter:
    def name(self, num):
        if num == -1:
            return "M"
        else:
            return str(num)

    def __init__(self):
        self.message = {}
        self.queue = multi.Queue()

        for i in range(NTHREADS):
            self.message[i] = "..."
        self.message[-1] = "..."

    def doprint(self):
        str = ''
        for i in range(NTHREADS + 1):
            str += '[' + self.name(i - 1) + '] ' + self.message[i - 1] + '\n'
        print(str + '-----------------')

    def parsemessages(self):
        doref = False
        while not self.queue.empty():
            i, m = self.queue.get()
            self.setmessage(m, i)
            doref = True

        if doref:
            self.doprint()

    def setmessage(self, mess, i):
        self.message[i] = mess.ljust(60)
        # self.doprint()


def tonumpyarray(mp_arr):
    a = np.frombuffer(mp_arr.get_obj(), dtype=np.float32)
    a.shape = ((int(len(mp_arr)/4), 4))
    return a


start_time = 0


def showprogress(messtring, i, queue, total):
    mes = "%s, %d/%d" % (
        messtring.ljust(10),
        itcounters[i],
        total
    )
    queue.put((i, mes))


output = Outputter()

killers = [False for i in range(NTHREADS)]

np.random.shuffle(pixelindices)
chunks = np.array_split(pixelindices, numPixels/CHUNKSIZE + 1)
NCHUNKS = len(chunks)

result_buffer = multi.Array(ctypes.c_float, numPixels * 4)
buffer_preproc = tonumpyarray(result_buffer)


background = plt.imread(
    'C:\\Users\\18786\\Desktop\\上课\\引力与宇宙学\\大作业\\kerr\\flip70.png')
bs0, bs1 = background.shape[:2]
disk = plt.imread(
    'C:\\Users\\18786\\Desktop\\上课\\引力与宇宙学\\大作业\\kerr\\akkretionsscheibe.png')
disk[:, :, 3] = np.power(np.mean(disk[:, :, :3], axis=2) - 0.005, 2)
ds0, ds1 = disk.shape[:2]

# =================================================================================================


def blendcolors(color1, color2):
    cb = color1[:3]
    balpha = color1[3]
    ca = color2[:3]
    aalpha = color2[3]
    color = np.zeros(4)
    color[:3] = ca + cb * (balpha*(1 - aalpha))
    color[3] = aalpha + balpha*(1 - aalpha)
    return color


def calstable():
    z1 = 1+(1-a*a)**1/3*((1+a)**1/3+(1-a)**1/3)
    z2 = (3*a*a+z1*z1)**0.5
    return 3+z2-((3-z1)*(3+z1+2*z2))**0.5


def delta(r):
    return r**2-2*r+a**2


def sigma(r, theta):
    return r**2+a**2*cos(theta)**2


def rtf2xyz(y):
    r = y[0]
    sintheta = sin(y[1])
    costheta = cos(y[1])
    sinphi = sin(y[2])
    cosphi = cos(y[2])
    tx = (r**2+a**2)**0.5*sintheta*cosphi
    ty = (r**2+a**2)**0.5*sintheta*sinphi
    tz = r*costheta
    vec = np.array([tx, ty, tz])
    return vec


def init(hp, wp, dp, num):
    i = num / RESOLUTION[1]
    j = num % RESOLUTION[1]

    h = hp/2-i*hp/(RESOLUTION[0]-1)
    w = -wp/2+j*wp/(RESOLUTION[1]-1)
    d = dp

    tempw = w*cos(rotate[2])-h*sin(rotate[2])
    temph = w*sin(rotate[2])+h*cos(rotate[2])
    w = tempw
    h = temph

    tempw = -d*sin(rotate[1])+w*cos(rotate[1])
    tempd = d*cos(rotate[1])+w*sin(rotate[1])
    w = tempw
    d = tempd

    tempd = d*cos(rotate[0])+h*sin(rotate[0])
    temph = -d*sin(rotate[0])+h*cos(rotate[0])
    d = tempd
    h = temph
    temp = np.array([w, h, d])
    w, h, d = temp/np.linalg.norm(temp)

    r = R0
    theta = THETA0
    if(THETA0 == 0):
        phi = PHI0-np.arctan2(w, d)
        d = np.abs(d)
    else:
        phi = PHI0
    _delta = delta(r)

    a2 = a**2
    r2 = r**2
    ar = a2+r2

    sintheta = sin(theta)
    costheta = cos(theta)

    pr = (h*ar*costheta+r*sqrt(ar)*sintheta*d) / _delta
    ptheta = (-h*r*sintheta+sqrt(ar)*costheta*d)
    phidot = (w*sintheta)/sqrt(ar)
    E = (1-2/r)+(2*a*phidot)/r
    L = -(2*a)/r+(r2+a2+(2*a2)/r)*phidot
    p = np.array([r, theta, phi, pr, ptheta, E, L])
    return p


def func_kerr(y, E, L):  # r,theta,fai,dr,dtheta
    f = zeros(5)

    r = y[0]
    sintheta = sin(y[1])
    costheta = cos(y[1])
    sin2 = sintheta**2
    _sigma = sigma(y[0], y[1])
    _delta = delta(y[0])
    rtwo = r*2

    f[0] = (y[3]*_delta)/_sigma

    f[1] = y[4]/_sigma

    f[2] = a*(-a*L+rtwo*E)/(_delta*_sigma)+L/(sin2 * _sigma)

    f[3] = -(1/(2*_delta**2*_sigma**2))*(_sigma*(-E*_delta*(a*2*(-2*L+a*E*sin2)+2*y[0]*E*_sigma) +
                                                 (a*(a*L**2-2*L*rtwo*E+a*rtwo*E**2*sin2)+y[3]**2 *
                                                     _delta**2+(a**2+y[0]**2)*E**2*_sigma)*2*(y[0]-1)) +
                                         _delta*(a*(L*(a*L-2*rtwo*E)+a*rtwo*E**2*sin2) -
                                                 _delta*(y[4]**2+L**2/sin2+y[3]**2*_delta))*2*y[0])

    f[4] = - (1/(2*_delta*_sigma**2))*(-2*sintheta*(a**2*rtwo*E**2*costheta
                                                    + L**2*costheta*sin2**-2*_delta)*_sigma
                                       + (a*(L*(a*L-2*rtwo*E)+a*rtwo*E**2*sin2)-_delta
                                          * (y[4]**2+L**2/sin2+y[3]**2*_delta))*(-2*a**2*sintheta*costheta))
    return f


def rk_step_1(y, h, E, L):
    k1 = func_kerr(y, E, L)
    k2 = func_kerr(y + 0.5*h*k1, E, L)
    k3 = func_kerr(y + 0.5*h*k2, E, L)
    k4 = func_kerr(y + h*k3, E, L)
    f = y + h/6 * (k1 + 2*k2 + 2*k3 + k4)
    return f, h, True


def rk_step_2(y, h, tol, E, L):
    c = np.array([0, 1/5, 3/10, 4/5, 8/9, 1, 1])  # t步长的，没用到
    a = np.array([
        [0, 0, 0, 0, 0, 0, 0],
        [1/5, 0, 0, 0, 0, 0, 0],
        [3/40, 9/40, 0, 0, 0, 0, 0],
        [44/45, -56/15, 32/9, 0, 0, 0, 0],
        [19372/6561, -25360/2187, 64448/6561, -212/729, 0, 0, 0],
        [9017/3168, -355/33, 46732/5247, 49/176, -5103/18656, 0, 0],
        [35/384, 0, 500/1113, 125/192, -2187/6784, 11/84, 0],
    ])
    b = np.array([35/384, 0, 500/1113, 125/192, -2187/6784, 11/84, 0])
    b_star = np.array([5179/57600, 0, 7571/16695, 393 /
                       640, -92097/339200, 187/2100, 1/40])

    k = np.zeros((7, len(y)))
    k[0] = func_kerr(y, E, L)
    for _ in range(10000):
        for l in range(1, 7):
            dy = np.dot(a[l], k)
            k[l] = func_kerr(y + h*dy, E, L)
        y_new = y + h*np.dot(b, k)
        y_star = y + h*np.dot(b_star, k)
        err = np.linalg.norm(y_new - y_star)

        if err < tol:
            if err < tol/100:
                h *= 2
            return y_new, h, True
        else:
            h = h * 0.9*(tol/err)**0.2
    print('!!!', h, err)
    return y_new, h, False


def process(p):
    f = p[:5]  # r,theta,fai,dr,dtheta,dfai
    E = p[5]
    L = p[6]
    old = f[:3]
    dt = 1
    color = np.zeros(4)
    for o in range(steps):
        if(f[0] < rin or sin(f[1]) < 0.05):
            f, dt, run = rk_step_2(f, dt, 1e-8, E, L)
        elif(f[0] < rout+1 and sin(f[1]) > 0.9 or sin(f[1]) < 0.5):
            dt = 0.1
            f, _, run = rk_step_1(f, dt, E, L)
        else:
            dt = max(dt, 1)
            f, _, run = rk_step_1(f, dt, E, L)
        if not (run):
            break
        if(f[0] < hori):
            color = blendcolors(np.array([0, 0, 0, 1]), color)
            break
        if(f[0] > R0*1.1):
            dv = rtf2xyz(f)-rtf2xyz(old)
            theta = np.arctan2((dv[0]**2+dv[1]**2)**0.5, dv[2])
            theta = np.modf(theta/pi)[0]
            phi = np.arctan2(dv[0], dv[1])
            phi = np.modf((phi+pi)/2/pi)[0]
            color = blendcolors(
                background[int(theta*bs0), int(phi*bs1)], color)
            break
        if(f[0] > rin and f[0] < rout and cos(f[1])*cos(old[1]) < 0.0001):
            if(f[1] == old[1]):
                d = 0
            else:
                d = (pi/2-old[1])/(f[1]-old[1])
            r = d*f[0]+(1-d)*old[0]-0.001
            phi = d*f[2]+(1-d)*old[2]
            r = np.modf((rout-r)/(rout-rin))[0]
            phi = np.modf((phi+pi)/2/pi)[0]
            color = blendcolors(disk[int(r*ds0), int(phi*ds1)], color)
        old = f[:3]
    if(o == steps-1):
        color = blendcolors(np.array([1, 0, 0, 1]), color)
    return color


# endregion

def raytrace(i, schedule, result_shared, q):
    if len(schedule) == 0:
        return
    temp_buffer = tonumpyarray(result_shared)
    schedule = np.hstack(schedule)
    total = len(schedule)

    for chunk in schedule:
        itcounters[i] += 1
        hp = 1
        wp = RESOLUTION[1]/RESOLUTION[0]*hp
        dp = -1.4
        p = init(hp, wp, dp, chunk)
        color = process(p)
        temp_buffer[chunk] = color
        showprogress('running', i, q, total)


if __name__ == '__main__':

    schedules = []
    q, r = divmod(NCHUNKS, NTHREADS)
    indices = [q*i + min(i, r) for i in range(NTHREADS+1)]
    for i in range(NTHREADS):
        schedules.append(chunks[indices[i]:indices[i+1]])

    start_time = time.time()
    process_list = []
    for i in range(NTHREADS):
        p = multi.Process(target=raytrace, args=(
            i, schedules[i], result_buffer, output.queue))
        process_list.append(p)

    for proc in process_list:
        proc.start()

    try:
        refreshcounter = 0
        while True:
            refreshcounter += 1
            time.sleep(0.01)

            if (refreshcounter % announce == 0):
                plt.imshow(buffer_preproc.reshape(
                    (RESOLUTION[1], RESOLUTION[0], 4)))
                plt.pause(0.01)
                output.parsemessages()

            alldone = True
            for i in range(NTHREADS):
                if process_list[i].is_alive():
                    alldone = False
            if alldone:
                break

    except KeyboardInterrupt:
        for i in range(NTHREADS):
            killers[i] = True
        sys.exit()

    print('Finish. Total raytracing time:', datetime.timedelta(
        seconds=(time.time() - start_time)))
    imgout = buffer_preproc.reshape((RESOLUTION[1], RESOLUTION[0], 4))
    plt.imsave('test.png', imgout)
    plt.imshow(imgout)
    plt.show()
